# MITRE-crown-jewel-map
This repo houses a simple mind-mapping tool built specifically for mapping out crown jewels as prescribed by MITRE here: 
https://www.mitre.org/publications/systems-engineering-guide/enterprise-engineering/systems-engineering-for-mission-assurance/crown-jewels-analysis. 

But can be used for a host of other tasks aswell.

###How To Install
1. `git pull`
2. `npm i` (in the cloned directory)
3 `ionic s`

Sometimes people have issues with their npm packages or node modules. This is a good resource to fixing most of those common issues:
https://stackoverflow.com/questions/50333003/could-not-find-module-angular-devkit-build-angular

###How To Use
Add as many 
